package main

func main() {
	StartCLI()
}
